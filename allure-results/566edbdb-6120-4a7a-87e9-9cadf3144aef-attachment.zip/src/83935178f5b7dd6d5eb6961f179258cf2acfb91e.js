import{test} from '@playwright/test'

test('Frames Handling1',async({page})=>{
    await page.goto("https://practice-automation.com/iframes/");
    const frame1=page.frameLocator("#iframe-1");
    await frame1.locator("//a[text()='MCP']").click();
    await frame1.locator('span[title="Installation"]').click();
});

test('Frames Handling2',async({page})=>{
      await page.goto("https://practice-automation.com/iframes/");
    const frame2=page.frameLocator("#iframe-2");
    await frame2.locator("//span[text()='Documentation']").click();
    await frame2.locator('#m-documentationwebdriver').click();

});

test('Multiple frameshandling',async({page})=>{
    await page.goto("https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");
    const frame3=page.frameLocator('[name="globalSqa"]');
    frame3.locator('img[data-image-title="DatabaseTestingTrainingNew"]').click();
     await page.waitForTimeout(2000); 
});

test('Multiple frameshandling1',async({page})=>{
    await page.goto("https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");
    const frame3=page.frameLocator('[name="globalSqa"]');
    frame3.locator('img[data-image-title="JMeterTraining"]').click();
    frame3.locator('#mobile_menu_toggler').click();
    frame3.locator("(//*[text()='About'])[2])").click();
    frame3.locator('.wpr-load-more-btn').click();
     await page.waitForTimeout(2000); 
});



